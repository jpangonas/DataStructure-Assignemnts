//Roster Number: 29
//
//Author: Jacob Pangonas
//Due Date: 3/28/18
//Programing Assignment 4
//
//Spring 2018 - CS 3358 - 01
//
//Instructor: Husain Gholoom
//
// This program compares two strings using stacks and queues
// to see if the strings are the same or are the reverse of
// one another
#include<iostream>
#include<limits>
using namespace std;
class stackC //class for the stack portion
{
private:
    char *stackArray; // the stack
    int stackSize; // size of stack
    int top; // top of stack

public:
    stackC(int); // constructor
    void push(char); // push element into stack
    void pop(char &); // pop top element of stack
    bool isFull() const; // check if stack is full
    bool isEmpty() const; // check if stack is empty

};

stackC::stackC(int SIZE)
{
    stackArray = new char[SIZE];
    stackSize = SIZE;
    top = -1;

}

void stackC::push(char c)
{
    if(isFull())
    {
        cout<< "The stack is full." << endl;
    }
    else
    {
        top++;
        stackArray[top] = c;
    }

}

void stackC::pop(char &c)
{
    if(isEmpty())
    {
        cout << "The stack is empty." << endl;

    }
    else
    {
        c = stackArray[top];
        top--;
    }
}

bool stackC::isFull() const
{
    bool stat;
    if(top == stackSize - 1)
    {
        stat = true;
    }
    else
    {
        stat = false;
    }
    return stat;
}

bool stackC::isEmpty() const
{
    bool stat;
    if(top == -1)
    {
        stat = true;
    }
    else
    {
        stat = false;
    }
    return stat;
}
/////////////////// Queue begins here ////////////////
class queueC // class for queue portion
{
private:
    char *queueCArray; // the queue
    int queueSize; // size of queue
    int frontQ; // front of queue
    int rearQ; // rear of queue
    int numItems; // number of items in queue
public:
    queueC(int); // constructor
    void enqueue(char); // add item to queue
    void dequeue(char &); // remove item from queue
    bool isEmptyQ(); // check if queue is empty
    bool isFullQ(); // check if queue is full

};

queueC::queueC(int SIZE)
{
    queueCArray = new char[SIZE];
    queueSize = SIZE;
    frontQ = -1;
    rearQ = -1;
    numItems = 0;
}

void queueC::enqueue(char c)
{
    if(isFullQ())
    {
        cout << "The queue is full" << endl;
    }
    else
    {
        if(rearQ == queueSize - 1)
        {
            rearQ = 0;
        }
        else
        {
            rearQ = rearQ + 1;
        }
        queueCArray[rearQ] = c;
        numItems++;
    }
}

void queueC::dequeue(char &c)
{
    if(isEmptyQ())
    {
        cout << "The queue is empty." << endl;
    }
    else
    {
        frontQ = (frontQ +1)% queueSize;
        c = queueCArray[frontQ];
        numItems--;
    }
}

bool queueC::isEmptyQ()
{
    bool stat;
    if(numItems != 0)
    {
        stat = false;
    }
    else
    {
        stat = true;
    }
    return stat;
}

bool queueC::isFullQ()
{
    bool stat;

    if(numItems < queueSize)
    {
        stat = false;
    }
    else
    {
        stat = true;
    }
    return stat;
}

int main()
{
    int finalChecker = 0; // check to get out of do while
    int userIn = 0;// user input for switch
    cout << "*** Welcome to My stack / Queue Program ***" << endl;
    cout << endl;
    cout << "The function of this program is to :" << endl << endl;
    cout << "   1. Use stack to determine whether or not" << endl;
    cout << "      two strings are the same." << endl << endl;
    cout << "   2. Use queue to determine whether or not"  << endl;
    cout << "      STRING2 is the reversed of STRING1" << endl << endl;
    do
    {
        cout << "Select from the following menu" << endl;
        cout << "   1. Enter Stack Values." << endl;
        cout << "   2. Enter Queue Values." << endl;
        cout << "   9. Terminate the program.   ";
        cin >> userIn;
        if(cin.fail()) // check for characters
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout << endl;
            cout << "Invalid Option" << endl;
        }
        else
        {
            cout << endl;
            switch(userIn)
            {
            case 1: //stack case
                {
                    string a; // initial string that user inputs
                    int checker = 0;// checker for # for pushing into the stack
                    int checker2 = 0;// checker to see if the two strings are equal or not
                    int record = 0; // spot after #
                    cout << "Enter Stack Values : ";
                    cin >> a;
                    cout  << endl;
                    int MAX = a.length(); // length of string
                    char b[MAX+1]; // char array for the string
                    stackC A = stackC(MAX);
                    for(int i = 0; i < MAX; i++)
                    {
                        b[i]= a[i];
                    }
                    for(int i = 0; i < MAX; i++)
                    {
                        if(b[i] == '#')
                        {
                            record = i+1;
                            checker = 1;
                        }
                        if(checker == 0)
                        {
                            A.push(b[i]);
                        }
                    }

                char checker3; // place to put popped value
                for(int i = MAX-1; i > record; i--)
                {
                    A.pop(checker3);
                    if(checker3 != b[i])
                    {
                    checker2 = 1;
                    }
                }
                if(checker2 == 1)
                    cout << "Strings are not identical" << endl << endl;
                else
                    cout << "Strings are identical" << endl << endl;
                }
            break;
            case 2:
                {//  queue begins
                string a; // initial string for queue
                cout << "Enter Queue Values : ";
                cin >> a;
                int MAX = a.length(); // max length of string
                char b[MAX+1]; // char array for the string
                int checkerQ = 0;// checker for # while enqueueing
                int checkerQ2 = 0;// checker to see if strings are reversed
                int recordQ = 0;// spot after #
                queueC B = queueC(MAX);
                for(int i = 0; i < MAX; i++)
                {
                    b[i]= a[i];
                }
                for(int i = 0; i<MAX; i++)
                {
                    if(b[i] == '#')
                    {
                        recordQ = i+1;
                        checkerQ = 1;
                    }
                    if(checkerQ == 0)
                    {
                        B.enqueue(b[i]);
                    }

                }
                char checkerQ3; // checker for dequeued char
                for(int i = MAX -1; i>recordQ; i--)
                {
                    B.dequeue(checkerQ3);
                    if(checkerQ3 != b[i])
                    {
                        checkerQ2 = 1;
                    }
                }
                if(checkerQ2 == 1)
                {
                    cout << endl;
                    cout << "STRING2 is not reversed of STRING1." << endl;
                    cout << endl;
                }
                else
                {
                    cout << endl;
                    cout << "STRING2 is reversed of STRING1." << endl << endl;
                }
            }
            break;
            case 9:
            finalChecker = 1;
            break;
            default:
            cout << "Invalid Option" << endl;
            }


        }
        cout << endl;

} while(finalChecker != 1);

cout << "*** End of the program. ***" << endl;
cout << "*** Written by Jacob Pangonas ***" << endl;
cout << "*** March 28 - 2018 ***" << endl;

return 0;
}

