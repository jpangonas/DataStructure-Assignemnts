//  Author: Jacob Pangonas Serial Number: 29
//  Due Date: 2/19/18
//  Programing Assignment 2
//  Spring 2018 - CS 3358 - 1
//
//  Instructor: Husain Gholoom
//
//  The purpose of this program is to calculate the average of the test
//  grades, programming assignment grades, and show them as well as the
//  overall average grade. All of the grades are retrieved by user input
//  and all the inputs can be deleted if the user wishes.

#include<iostream>
#include<limits>
#include<iomanip>
#include<vector>
using namespace std;

class MyGrades
{
private:
    vector<double> assignmentGrades; // vector to hold programing assignment grades
    vector<double> testGrades; // vector to hold test grades
public:
   MyGrades(); // constructor if needed
   void setAssignmentGrades();// function to set assignment grade
   void setTestGrades(); // function to set test grade
   void showAssignmentGrades(); // function to show and average assignment grades
   void showTestGrades(); // function to show and average test grades
   void showOverallGrade(); // function to show and average overall grade
   void deleteAnAssignment(); // function to delete an assignment grade
   void deleteATest(); // function to delete a test grade
};

MyGrades::MyGrades()
{
    assignmentGrades = vector<double>(); //initializes the assignmentGrades vector
    testGrades = vector<double>(); //initializes the testGrades vector
}

void MyGrades::setAssignmentGrades()
{
    double assignmentGrade = 0; // input for the assignment grade
    cout << "Enter A Programming Assignment grade:  ";
    cin >> assignmentGrade;
    if(cin.fail()) // check for valid input
    {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
        cout << "Error *** You entered a character" << endl << endl;

    }
    else
    {
        if(assignmentGrade > 10 || assignmentGrade < 0) // check for valid input
        {
            cout << "Error *** Invalid Assignment Grade" << endl << endl;
        }
        else
        {
            assignmentGrades.push_back(assignmentGrade);
            cout << endl;
        }

    }

}

void MyGrades::setTestGrades()
{
    double testGrade = 0; // test grade input
    cout << "Enter A Test Grade:  ";
    cin >> testGrade;
    if(testGrades.size() < 2) //checks to see if there are already 2 test grades
    {
        if(cin.fail()) // check for valid input
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout << endl << "Error *** You entered a character" << endl << endl;

        }
        else
        {
            if(testGrade > 25 || testGrade < 0) // check for valid input
            {
                cout << endl << "Error *** Invalid Test Grade" << endl <<endl;
            }
            else
            {
            testGrades.push_back(testGrade);
            cout << endl;
            }
        }
    }
    else
    {
        cout << endl << "Error *** There can only be two test grades" << endl <<endl;
    }


}

void MyGrades::showAssignmentGrades()
{
    double average = 0; // variable for the average
    double sum = 0; // variable for the sum of the assignments
    if(assignmentGrades.size() == 0) // checks to see if vector is empty
    {
        cout << "No Programing Assignment Grades are recorded" << endl;
    }
    else
    {
        cout << "Show all Programing Assignment Grades with Average." << endl;
        cout << "Programing Assignment Grades are As Follows" << endl;
        for(int i = 0; i < assignmentGrades.size(); i++)
        {
            cout << assignmentGrades.at(i) << " ";
            sum = sum + assignmentGrades.at(i); // calculate the sum of the assignment grades
        }
        average = (sum/assignmentGrades.size())*2; // calculate the average out of 20
        cout << "Average Programing Assignments is " << average << " Out of 20" << endl;
    }
    cout << endl;
}

void MyGrades::showTestGrades()
{
    double sumT = 0; // variable to calculate the sum of the test grades
    if(testGrades.size() == 0) // checks to see if vector is empty
    {
        cout << "No Test Grades are recorded" << endl;
    }
    else
    {
        cout << "Show all Test Grades with Average." << endl;
        cout << "Test are As Follows" << endl;
        for(int i = 0; i < testGrades.size(); i++)
        {
            cout << testGrades.at(i) << " ";
            sumT = sumT + testGrades.at(i);
        }
        if(testGrades.size() == 1)
        {
            cout << "Average Test Grades is " << sumT << " out of 20" << endl;
        }
        else
        {
            cout << "Average Test Grades is " << sumT << " Out of 45" << endl;
        }
    }
    cout << endl;
}

void MyGrades::showOverallGrade()
{
    cout << "Show Overall All Grades." << fixed << setprecision(2) << endl <<endl;
    cout << "My Overall Grades so far are as follows  :" << endl << endl;
    ///////////////Assignment portion starts here///////////////
    double average = 0;
    double sum = 0;
    int testP = 0; // variable to test what to put as the final average
    if(assignmentGrades.size() == 0) // checks to see if vector is empty
    {
        cout << "No Programing Assignment Grades are recorded" << endl;
    }
    else
    {
        cout << "Programing Assignment Grades are As Follows" << endl;
        for(int i = 0; i < assignmentGrades.size(); i++)
        {
            cout << assignmentGrades.at(i) << " ";
            sum = sum + assignmentGrades.at(i); // calculate the sum of the assignment grades
        }
        average = (sum/assignmentGrades.size())*2;
        cout << endl;
        cout << "Average Programing Assignments is " << average << " Out of 20" << endl; // calculate the average
        testP = 1;
    }
    cout << endl;
    ///////////////Test portion starts here///////////////
    double sumT = 0;
    int testT = 0; // variable to test what to put as the final average
        if(testGrades.size() == 0) // checks to see if vector is empty
    {
        cout << "No Test Grades are recorded" << endl;
    }
    else
    {
        cout << "Test Grades are As Follows" << endl;
        for(int i = 0; i < testGrades.size(); i++)
        {
            cout << testGrades.at(i) << " ";
            sumT = sumT + testGrades.at(i); //calculate the test grades average
        }
        if(testGrades.size() == 1)
        {
            cout << endl;
            cout << "Average Test Grades is " << sumT << " out of 20" <<endl;
            testT = 1;
        }
        else
        {
            cout << endl;
            cout << "Average Test Grades is " << sumT << " Out of 45" << endl << endl;
            testT = 2;
        }

    }
    cout << endl;
    if(testP == 0 && testT == 0) // if nothing is recored
    {
        cout << "No Grades have been recorded" << endl;
    }
    if(testP == 1 && testT == 0) //if there are assignments bu no tests
    {
        cout << "Overall Total -- > " << average << " out of 20" << endl;
    }
    if(testP == 0 && testT == 1) //if there are tests but no assignments
    {
        cout << "Overall Total -- > " << sumT << " out of 20" << endl;
    }
    if(testP == 0 && testT == 2) //if there are two tests but no assignments
    {
        cout << "Overall Total -- > " << sumT << " out of 45" << endl;
    }
    if(testP == 1 && testT == 1) // if there are assignments and 1 test
    {
        cout << "Overall Total -- > " << sumT + average << " out of 40" << endl;
    }
        if(testP == 1 && testT == 2) // if there are assignments and 2 tests
    {
        cout << "Overall Total -- > " << sumT + average << " out of 65" << endl;
    }
    cout << endl;
}
void MyGrades::deleteAnAssignment()
{
    double test = -1; // variable to test if the grade exists and to set position of the grade that will be deleted
    double dGrade = 0; // user input for grade to be deleted
    cout << "Enter A Program Grade to be Deleted: ";
    cin >> dGrade;
        if (cin.fail()) // check for valid input
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout << endl;
            cout << "Error *** You entered a character" << endl;
        }
        else
        {
            cout << endl;
            if(assignmentGrades.size() > 0) // checks to see if vector is empty
            {
                for(int i = 0; i < assignmentGrades.size(); i++)
                {
                    if(assignmentGrades.at(i) == dGrade)
                    {
                        test = i;
                    }
                }
                if(test == -1) // check to see if the grade doesn't exist
                {
                    cout << endl << "Programing Grade Does Not Exist" << endl << endl;
                }
                else
                {
                    cout << dGrade << " is Deleted" << endl;
                assignmentGrades.erase(assignmentGrades.begin()+test);
                cout << endl;
                }
            }
            else
            {
                cout << endl << "Programing Grade Does Not Exist" << endl << endl;
            }

        }
    }

void MyGrades::deleteATest()
{
    double test = -1; // variable to test if the grade exists and to set position of the grade that will be deleted
    double dGrade = 0; // user input for grade to be deleted

    cout << "Enter a Test Grade to be Deleted: ";
    cin >> dGrade;
        if (cin.fail()) // check for valid input
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout << endl;
            cout << "Error *** You entered a character" << endl;
        }
        else
        {
            cout << endl;
            if(testGrades.size()>0) // checks to see if vector is empty
            {
                for(int i = 0; i < testGrades.size(); i++)
                {
                    if(testGrades.at(i) == dGrade)
                    {
                        test = i;
                    }
                }
            if(test == -1) // check to see if the grade doesn't exist
            {
                cout << endl << "Test Grade Does Not Exist" << endl << endl;
            }
            else
            {
                cout << dGrade << " is Deleted" << endl;
                testGrades.erase(testGrades.begin()+test);
                cout << endl;
            }
            }
            else
            {
                cout << "Test Grade Does Not Exist" << endl << endl;
            }


        }

    }

int main()
{
    int userIn = 0; // variable for the user input
    double test = 0; // test variable to check if the user wants to end the program
    MyGrades A = MyGrades(); // constructor
    cout << "Welcome to My Grades APP." << endl <<endl;
    do
    {
        cout << "   1. Set A Programming Assignment Grade" << endl;
        cout << "   2. Set A Test Grade" << endl;
        cout << "   3. Show All Programing Assignment Grades" << endl;
        cout << "   4. Show All Test Grades" << endl;
        cout << "   5. Show Overall Grades" << endl;
        cout << "   6. Delete A Programing Assignment Grades" << endl;
        cout << "   7. Delete A Test Grade" << endl;
        cout << "   9. Exit The Program" << endl << endl;
        cout << "Enter your choice ---> ";
        cin >> userIn;
        if(cin.fail()) // check for characters
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout << endl << endl;
            cout << "Error *** Incorrect input - You entered a character / s" << endl;
            cout << "Enter a Positive Integer" << endl << endl;
        }
        else if(userIn == 8 || userIn > 9 || userIn <= 0) // check for numerical values that are not taken
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout << endl;
            cout << "Error *** You entered invalid choice" << endl << endl;
        }
        else
        {
            cout << endl;
            switch(userIn)
            {
                case 1: A.setAssignmentGrades();
                cin.clear();
                    break;
                case 2: A.setTestGrades();
                cin.clear();
                    break;
                case 3: A.showAssignmentGrades();
                cin.clear();
                    break;
                case 4: A.showTestGrades();
                cin.clear();
                    break;
                case 5: A.showOverallGrade();
                cin.clear();
                    break;
                case 6: A.deleteAnAssignment();
                cin.clear();
                    break;
                case 7: A.deleteATest();
                cin.clear();
                    break;
                case 9: test = 1;
                    break;
            }

        }

    }while(test == 0);
    cout << endl;
    cout << "Implemented by Jacob Pangonas" << endl;
    cout << "February - 2018" << endl;

    return 0;
}
