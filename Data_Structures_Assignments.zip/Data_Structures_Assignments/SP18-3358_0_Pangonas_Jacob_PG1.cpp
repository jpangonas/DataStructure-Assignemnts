// Author: Jacob Pangonas
// Due Date: 2/5/18
// Serial Number: 29
//Programing Assignment #1
//Spring 2018 - CS 3358 - 000
//
//Instructor: Husain Gholoom
//
//This program creates 2 2-D arrays and displays information such as
//the sums of the rows an columns as well as the diagonals and see if
// the array is a special array

#include<iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
void printInfo();
void fillArrays(int [][3], int [][3], int); //Function to fill the arrays
void displayArrays(int [][3], int [][3], int); //Function to display Array_1 and Array_2
void addArrays(int [][3], int [][3], int); // Function to add and display Array_1 and Array_2
void multArrays(int [][3], int [][3], int); // Function to multiply and display Array_1 and Array_2
void transposeArray(int [][3], int); // Function to find and display the transpose of Array_1
void determinantArray(int [][3]); // Function to find and display the determinant of Array_1
void addRows(int [][3], int); // Function to find and display the sum of the rows in Array_1
void addColumns(int [][3], int); //Function to find and display the sum of the columns in Array_1
void addDiag(int[][3], int); // Function to find and display the sum of both diagonals in Array_1
void specialArray(int[][3], int); // function to check if Array_1 is a special array

int main()
{
    const int SIZE = 3;
    int Array_1[SIZE][SIZE];
    int Array_2[SIZE][SIZE];
    char userIn = 'y'; //the user input to see if they would wish to continue the program
    printInfo();
    do{
    fillArrays(Array_1, Array_2, SIZE);
    displayArrays(Array_1, Array_2, SIZE);
    addArrays(Array_1, Array_2, SIZE);
    multArrays(Array_1, Array_2, SIZE);
    transposeArray(Array_1, SIZE);
    determinantArray(Array_1);
    addRows(Array_1, SIZE);
    addColumns(Array_1, SIZE);
    addDiag(Array_1, SIZE);
    specialArray(Array_1, SIZE);
    cout << "Would you like to check another Array - Enter y or Y for yes" << endl << "or n | N for no  ";
    cin >> userIn;
        while(userIn != 'y' && userIn != 'Y' && userIn != 'n' && userIn != 'N')
        {
            cout << "Error *** Invalid choice - Must enter y | Y | n | N" << endl << endl;
            cout << "Would you like to check another Array - Enter y or Y for yes" << endl << "or n | N for no  ";
            cin >> userIn;
        }
    }while(userIn == 'y'|| userIn == 'Y');
    cout << endl << "This algorithm is implemented by Jacob Pangonas" << endl;
    return 0;
}

void printInfo()
{
    cout << "Welcome to my Array program. The function of the program is to" << endl << endl;
    cout << "1. Create 2 Arrays ( Array_1 , Array_2 ). Each Array is of size 3 x 3." << endl;
    cout << "2. Populate both Arrays with distinct random numbers that are between 1 and" << endl;
    cout << "   12. Display both Arrays." << endl;
    cout << "3. Adding and multiplying Array_1 and Array_2." << endl;
    cout << "4. Displaying the transposed and the determinate of Array_1 ." << endl;
    cout << "5. Displaying the sum of the elements of each row of Array_1, displaying the sum of" << endl;
    cout << "   elements of each column of Array_1, displaying the sum of both diagonal" << endl;
    cout << "   elements of Array_1." << endl;
    cout << "6. Finally , determining whether or not Array_1 is a special array." << endl << endl;
    cout << "7. Repeating the above steps until the user terminates the program." << endl << endl;
}

void fillArrays(int array1[][3],int array2[][3],int s)
{
    int Max = 12; //Max number that wants to be generated
    int array_NumsFor1[Max]; //numbers to go into Array_1
    int array_NumsFor2[Max]; //numbers to go into Array_2
        srand(time(NULL));
    for (int a = 0; a<Max; a++) //adds numbers 1 - Max to an array
    {
        array_NumsFor1[a] = 0;
    }

        int test1 = 1; //Test variable to see if any numbers are similar in the array
        int counterA = 0; // A counter to go through the do while loop
        int ranNumber = std::rand() % Max; //randomly generated number between 1 and Max
        do
        {
            ranNumber = std::rand() % Max;
            for(int i = 0; i < Max; i++)
            {
                if(array_NumsFor1[i] == ranNumber)
                {
                    test1 = 0;
                }
            }
            if(test1 == 1)
            {
                array_NumsFor1[counterA] = ranNumber;
                counterA++;
            }
            test1 = 1;
        }while(counterA < 11);


        for (int c = 0; c<Max; c++) //adds numbers 1 - Max to an array
    {
        array_NumsFor2[c] = 0;
    }
        int test2 = 1; //Test variable to see if any numbers are similar in the array
        int counterB = 0;// A counter to go through the do while loop
        do
        {
            ranNumber = std::rand() % Max;
            for(int i = 0; i < Max; i++)
            {
                if(array_NumsFor2[i] == ranNumber)
                {
                    test2 = 0;
                }
            }
            if(test2 == 1)
            {
                array_NumsFor2[counterB] = ranNumber;
                counterB++;
            }
            test2 = 1;
        }while(counterB < 11);

    int counter1=0; // used to count through the generated array
    int counter2=0; // used to count through the generated array
    for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++) //adds the random numbers to the 2D Array (Array_1)
        {
            array1[i][j] = array_NumsFor1[counter1];
            counter1++;
        }
    }

        for (int i = 0; i < s; i++) //adds the random numbers to the 2D Array (Array_2)
    {
        for (int j = 0; j<s; j++)
        {
            array2[i][j] = array_NumsFor2[counter2];
            counter2++;
        }
    }
}


void displayArrays(int array1[][3], int array2[][3], int s)
{
    cout << "Array_1  :" << endl << endl;
    for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++)
        {
            cout << array1[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
    cout << "Array_2  :" << endl << endl;
        for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++)
        {
            cout << array2[i][j] << " ";
        }
        cout << endl;
    }
}

void addArrays(int array1[][3], int array2[][3], int s)
{
    int Array_3[s][s];
    for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++)
        {
            Array_3[i][j] = array1[i][j] + array2[i][j];
        }
    }
    cout << endl;
    cout << "Sum of Array 1 and Array 2 " << endl << endl;
    for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++)
        {
            cout << Array_3[i][j] << " ";
        }
        cout << endl;
    }
}

void multArrays(int array1[][3], int array2[][3], int s)
{
    int Array_3[s][s];
    for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++)
        {
            Array_3[i][j] = array1[i][j] * array2[i][j];
        }
    }
    cout << endl;
    cout << "Product of Array 1 and Array 2 " << endl << endl;
    for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++)
        {
            cout << Array_3[i][j] << " ";
        }
        cout << endl;
    }
}

void transposeArray(int array1[][3], int s)
{
    cout << endl;
    cout << "Transpose of Array 1" << endl << endl;
    for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++)
        {
            cout << array1[j][i] << " ";
        }
        cout << endl;
    }
}

void determinantArray(int array1[][3])
{
    cout << endl;
    int determinant = 0;
    int chunck1 = 0; //a(ei-fh)
    int chunck2 = 0; //b(di-fg)
    int chunck3 = 0; //c(dh-eg)
    chunck1 = (array1[0][0]*((array1[1][1]*array1[2][2])-(array1[1][2]*array1[2][1])));
    chunck2 = (array1[0][1]*((array1[1][0]*array1[2][2])-(array1[1][2]*array1[2][0])));
    chunck3 = (array1[0][2]*((array1[1][0]*array1[2][1])-(array1[1][1]*array1[2][0])));
    determinant = chunck1 - chunck2 + chunck3;
    cout << "Determinate of Array 1    =  " << determinant << endl;
}

void addRows(int array1[][3], int s)
{
    cout << endl;
    int sumR = 0; //the sum of the row
        for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++)
        {
            sumR = sumR + array1[i][j];
        }
        cout << "Sum of numbers in Row #    " << i+1 << " in Array 1    =   " << sumR << endl;
        sumR = 0;
    }

}

void addColumns(int array1[][3], int s)
{
    cout << endl;
    int sumC = 0; // the sum of the columns
        for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++)
        {
            sumC = sumC + array1[j][i];
        }
        cout << "Sum of numbers in Column #    " << i+1 << " in Array 1    =   " << sumC << endl;
        sumC = 0;
    }

}

void addDiag(int array1[][3], int s)
{
    cout << endl;
    int sumD1 = 0; // sum of diagonal 1
    int sumD2 = 0; // sum of diagonal 2
    for(int i = 0; i<s; i++)
    {
        sumD1 = sumD1 + array1[i][i];
    }
    cout << "Sum of numbers in first diagonal   in Array 1    =   " << sumD1 << endl;
    int ss = s-1; //counter to go through the array
    for (int i = 0; i<s; i++)
    {
        sumD2 = sumD2 + array1[i][ss];
        ss--;
    }
    cout << "Sum of numbers in second diagonal   in Array 1    =   " << sumD2 << endl;
}

void specialArray(int array1[][3], int s)
{
    int spNum = ((s*(s^2+1))/2); // the special number
    cout << endl << "The special number is 15" << endl << endl;
    int spD1 = 0; // sum of diagonal 1
    int spD2 = 0; // sum of diagonal 2
    int spC = 0;  // sum of rows
    int spR = 0;  // sum of columns
        for(int i = 0; i<s; i++)
    {
        spD1 = spD1 + array1[i][i];
    }

    int ss = s-1;
    for (int i = 0; i<s; i++)
    {
        spD2 = spD2 + array1[i][ss];
        ss--;
    }
    int arrayC[s]; //array to hold the values of the sums of the Columns
    int arrayR[s]; //array to hold the values of the sums of the Rows
    for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++)
        {
            spC = spC + array1[j][i];
        }
        arrayC[i] = spC;
        spC = 0;
    }
    for (int i = 0; i < s; i++)
    {
        for (int j = 0; j<s; j++)
        {
            spR = spR + array1[i][j];
        }
        arrayR[i] = spR;
        spR = 0;
    }
    int test = 1; // a test variable to see if the numbers in arrayR are the special number
    int test2 =1; // a test variable to see if the numbers in arrayC are the special number
    for (int i = 0; i < s; i++)
        {
            if (arrayR[i] != spNum)
            {
                test = 0;
            }

        }
        for (int i = 0; i < s; i++)
        {
            if (arrayC[i] != spNum)
            {
                test2 = 0;
            }

        }
    if(spD1 == spNum && spD2 == spNum && test == 1 && test2 == 1)
    {
        cout << "The above is Special Array" << endl << endl;

    }
    else
        cout << "The above is not a special Array" << endl << endl;
}
