//Roster Number: 29
//
// Author: Jacob Pangonas
// Due Date: 4/25/18
// Programming Assignment 6
//
// Spring 2018 - CS 3358 - 01
//
// Instructor: Husain Gholoom
//
// This program builds a binary tree displays it in pre and post order,
// displays all left and right sub roots, and counts and displays all
// the leaves of the tree

#include<iostream>
using namespace std;
class BinarySearchTree
{
public:
    int SIZE;
    int* array; // array to hold the tree
    int counter2; // counter to count size of the array
    void insertNode(int x); // function to add nodes to tree
    //void searchElement(int x); part of Gholoom's program
    void parent(int x);
    int extendSize(int x);
    void displayNodes(); // function to display all the nodes of the array
    void preOrder(int); // function to display the array in pre order
    void postOrder(int);// function to display the array in post order
    void displayRSR(); // function to display all the right sub roots
    void displayLSR();// function to display all the left sub roots
    void treeLeafsCount(); // function to count the leaves
    void displayLeafValues();// function to display the leaves


    BinarySearchTree(int SIZE)
    {
        int newSize = extendSize(SIZE);
        array = new int[newSize];
        for(int x = 0; x < SIZE; x++)
        {
            array[x] = 0;
        }
        counter2 = 0;
    }
};

int BinarySearchTree::extendSize(int x)
{
    int value = 0;
    for(int y = 0; y < x+1; y++)
    {
        value = (2*value)+2;
    }
    return value;
}

void BinarySearchTree::insertNode(int x)
{
    int currentIndex = 0;
   // cout << "Adding: " << x;
    while(true)
    {
        if(array[currentIndex]== 0)
        {
            array[currentIndex] = x;
            //cout << " Inserted at index: "<<currentIndex<<endl;
            break;
        }
        else if(array[currentIndex]<= x)
        {
            if(array[currentIndex]== x)
            {
                //cout << "ERROR!-- Repeating element"<<endl;
                break;
            }
            else
               // cout << " Right ";
                counter2++;
            currentIndex = (2*currentIndex+2);
        }
        else if(array[currentIndex]>=x)
        {
            if(array[currentIndex]== x)
            {
                //cout << "ERROR!-- Repeating element"<<endl;
                break;
            }
            else
                //cout << " Left ";
                counter2++;
            currentIndex = (2*currentIndex+1);
        }
    }
}

/*void BinarySearchTree::searchElement(int x)
{
    int currentIndex = 0;
    while(true)
    {
        if(array[currentIndex]==0)
        {
            cout << "Not Found"<<endl;
            break;
        }
        if(array[currentIndex]==x)
        {
            cout << "Found at index: "<<currentIndex<<endl;
            break;
        }
        else if(array[currentIndex]<x)
        {
            currentIndex = (2*currentIndex+2);
        }
        else if(array[currentIndex]>x)
        {
            currentIndex = (2*currentIndex+1);
        }
    }
}*/

void BinarySearchTree::parent(int x)
{
    while(x!=0)
    {
        x = (x-1)/2;
        //cout << "---";
    }
}
void BinarySearchTree::displayNodes()
{
    int i =0; // value to go through the tree
    while(i<counter2+1)
    {
        if(array[i]==0)
        {
            cout << i+1 <<": "<<"empty"<<endl;
            i++;
        }
        else
        {
            cout << i+1 << ": "<< array[i] << endl;
            i++;
        }
    }
}

void BinarySearchTree::preOrder(int x)
{
    //x is a variable to keep track of the index
    if(array[x] != 0)
    {
        cout << array[x]<< " " << endl;
        preOrder(2*x+1);
        preOrder(2*x+2);
    }
}

void BinarySearchTree::postOrder(int x)
{
    //x is a variable to keep track of the index
    if(array[x] != 0){
        postOrder(2 * x + 1);
        postOrder(2 * x + 2);
        parent(x);
        cout << array[x] << " " << endl;
    }
}

void BinarySearchTree::displayRSR()
{
    int i = 0; // value to go through the tree
    i = (i*2)+2;
    while(i<counter2)
    {
        if(array[i]==0)
        {
            i = (i*2)+2;
        }
        else
        {
            cout << array[i] << endl;
            i = (i*2)+2;
        }
    }
}

void BinarySearchTree::displayLSR()
{
    int i = 0; // value to go through the tree
    i = (i*2)+1;
    while(i<(counter2/2))
    {
        if(array[i]==0)
        {
            i = (i*2)+1;
        }
        else
        {
            cout << array[i] << endl;
            i = (i*2)+1;
        }
    }
}

void BinarySearchTree::treeLeafsCount()
{
    int i =0; // value to go through the tree
    int counterL =0; //counter for leaves
    while(i<counter2)
    {
        if(array[(i*2)+1]==0 && array[(i*2)+2]==0 && array[i]!=0)
        {
            i++;
            counterL++;
        }
        else
        {
            i++;
        }
    }
    cout << counterL;
}

void BinarySearchTree::displayLeafValues()
{
    int i =0;// value to go through the tree
    int j= 0;//value to count the leaves
    int temp;// temp value for swapping
    int arrayLeaves[counter2]; // array to hold the leaves for sorting
    while(i<counter2)
    {
        if(array[(i*2)+1]==0 && array[(i*2)+2]==0 && array[i]!=0)
        {
            arrayLeaves[j]=array[i];
            j++;
            i++;
        }
        else
        {
            i++;
        }
    }
    for(int h=0; h<j-1;h++)
    {
        for(int k=0; k<j-h-1; k++)
        {
            if(arrayLeaves[k]>arrayLeaves[k+1])
            {
                temp = arrayLeaves[k];
                arrayLeaves[k]=arrayLeaves[k+1];
                arrayLeaves[k+1]=temp;
            }
        }
    }
    for(int g=0;g<j;g++)
    {
        cout << arrayLeaves[g] << endl;
    }
}

int main()
{
    BinarySearchTree tree(13);
    cout << "Binary Search Tree by Jacob Pangonas\n\n";
    cout << "Inserting nodes.\n\n";
    tree.insertNode(70);
    tree.insertNode(50);
    tree.insertNode(100);
    tree.insertNode(30);
    tree.insertNode(60);
    tree.insertNode(80);
    tree.insertNode(110);
    tree.insertNode(20);
    tree.insertNode(68);
    tree.insertNode(90);
    tree.insertNode(120);
    tree.insertNode(25);
    tree.insertNode(62);
    cout << endl;
    cout << "Building BST completed.\n\n";

    cout << "Values of the Binary Search tree.\n\n";
    tree.displayNodes();
    cout << "\n\nPre-Order Traversal :\n\n";
    tree.preOrder(0);
    cout << endl;
    cout << "Post-Order Traversal :\n\n";
    tree.postOrder(0);
    cout << endl;
    cout << "Here are all right sub roots for the BST :\n\n";
    tree.displayRSR();
    cout << "\n\nHere are all left sub root values for the BST: \n\n";
    tree.displayLSR();
    cout << "\n\nNumber of Leafs : ";
    tree.treeLeafsCount();
    cout << "\n\nHere are the leaf values in the BST: \n\n";
    tree.displayLeafValues();
    cout << endl << "April 25, 2018"<< endl << endl;
    cout << "Written by Jacob Pangonas" << endl;


    return 0;
}
