//  Roster Number; 29
//
//  Author: Jacob Pangonas
//
//  Programing Assignment 3
//
// Spring 2018 - CS 3358 - 01
//
// Due Date: 3/5/18
//
// Instructor: Husain Gholoom
//
// This program randomly generates two linked lists, combines them,
// counts the number of times the first element appears in the combined list
// removes the duplicates in the list, counts the elements after duplicates
// are removed, displays the new list backward, moves the last element between
// the 3rd and 4th element, then sorts the list in ascending order

#include<iostream>
#include <cstdlib>
#include <ctime>
using namespace std;


class LinkedList
{
private:
    struct ListNode
    {
        int value;
        ListNode* next;
    };
    ListNode* list_1;
    ListNode* list_2;
    ListNode* list_3;
    ListNode* list_4;
public:
    LinkedList(); //constructor
    void buildLists(); //builds list_1 and list_2 with random numbers between 1 and 19
    void List3(); // combines list_1 and list_2 into list_3 then displays list_3
    void displayFOccur(); //displays how many times the first item of list_3 appears
    void removeDups(); // removes the duplicates of list_3 and makes list_4 out of it
    void countEle(); // counts the elements of list_4
    void disListBack(); // displays list_4 in reverse
    void moveEle(); //moves the last element of list_4 between the 3rd and 4th element of list_4
    void sortList(); //sorts list_4 in ascending order


};

LinkedList:: LinkedList()
{
    ListNode* list_1 = new ListNode();
    ListNode* list_2 = new ListNode();
    ListNode* list_3 = new ListNode();
    ListNode* list_4 = new ListNode();
}
void LinkedList:: buildLists()
{
    int Max = 18; // max number that can be randomly generated before the +1
    int listSize = 15; // ma size of initial list
    int ranNumber = 0; // number to be generated
    srand(time(NULL));
    ListNode* current = list_1; // temp node
    for(int i = 0; i < listSize; i++) // builds list_1
    {
        ranNumber = std::rand() % Max;
        ranNumber++;
        ListNode* newNode = new ListNode();
        newNode ->value = ranNumber;
        if(i == 0)
        {
            list_1 = newNode;
            current = list_1;
        }
        else
        {
            current -> next = newNode;
            current = current -> next;
        }

    }

    ListNode* current2 = list_2; // temp node
    for(int i = 0; i < listSize; i++) // builds list_2
    {
        ranNumber = std::rand() % Max;
        ranNumber++;
        ListNode* newNode = new ListNode();
        newNode ->value = ranNumber;
        if(i == 0)
        {
            list_2 = newNode;
            current2 = list_2;
        }
        else
        {
            current2 -> next = newNode;
            current2 = current2 -> next;
        }

    }
    cout << "list_1 consists of: ";
    current = list_1;
    while(current != NULL) // displays list_1
    {
        cout << current->value << " ";
        current = current -> next;
    }
    cout << endl << endl;
    cout << "list_2 consists of: ";
    current = list_2;
    while(current != NULL) // displays list_2
    {
        cout << current->value << " ";
        current = current -> next;
    }
    cout << endl;

}

void LinkedList:: List3()
{
    ListNode* current; // temp node
    ListNode* current2;// temp node
    current = list_1;
    int case1 = 0;
    while(current != NULL) //puts list_1 into list_3
    {
        ListNode* newNode3 = new ListNode();
        newNode3 -> value = current -> value;
        if(case1 == 0)
        {
            list_3 = newNode3;
            current2 = list_3;
            current = current -> next;
            case1 = 1;
        }
        else
        {
            current2 -> next = newNode3;
            current2 = current2 -> next;
            current = current -> next;
        }
    }

    current = list_2;
    while(current != NULL) // puts list_2 into list_3
    {
        ListNode* newNode3 = new ListNode();
        newNode3 -> value = current -> value;
        {
            current2 -> next = newNode3;
            current2 = current2 -> next;
            current = current -> next;
        }
    }


    cout << endl;
    current = list_3;
    cout << "list_3 contains the values of list_1 then list_2." << endl;
    cout << endl <<"list_3 consists of: ";
    while(current != NULL) // display list_3
    {
        cout << current->value << " ";
        current = current -> next;
    }
    cout << endl;


}

void LinkedList::displayFOccur()
{
    int firstValue = 0; // variable to check for first value
    ListNode* current;// temp node
    current = list_3;
    firstValue = list_3 -> value;
    int counter = 0; // counter for how many times first value occurs
    while(current!= NULL)
    {
        if(current -> value == firstValue)
        {
            counter++;
        }
        current = current -> next;
    }
    cout << endl;
    cout << "The first value of list_3 appears " << counter << " times.";
    cout << endl << endl;
}

void LinkedList::removeDups()
{
    ListNode* current; // temp node
    ListNode* current2;// temp node
    ListNode* current3;// temp node
    ListNode* current4;// temp node
    list_4 = list_3;
    current = list_4;

    while(current != NULL && current ->next != NULL) // builds list_4 by only deleting the duplicate numbers from list_3
    {
        current2 = current;

        while(current2 -> next != NULL)
        {
            if(current -> value == current2->next->value)
            {
                current3 = current2 ->next;
                current2 -> next = current2->next->next;
                delete(current3);
            }
            else
            {
                current2 = current2->next;
            }
        }
        current = current->next;
    }

    cout << "list_4 is list_3 with all duplicates removed.";
    cout << endl << endl;
    cout << "list_4 consists of: ";

    current4 = list_4;
    while(current4 != NULL) // display list_4
    {
        cout << current4->value << " ";
        current4 = current4 -> next;
    }
    cout << endl << endl;

}

void LinkedList::countEle()
{
    ListNode* current;// temp node
    int counter = 0; // counter for elements in list_4
    current = list_4;
    while(current != NULL)
    {
        current = current ->next;
        counter++;
    }
    cout << "The Number of elements in list_4 = " << counter << endl;
}

void LinkedList::disListBack()
{
    ListNode* current; // temp node
    ListNode* current2; // temp node
    ListNode* temp1; //previous node
    ListNode* temp2; // next node
    temp1 = NULL;
    current = list_4;
    while(current != NULL)
    {
        temp2 = current->next;
        current ->next = temp1;
        temp1 = current;
        current = temp2;

    }
    list_4 = temp1;
    current2 = list_4;
    cout << endl;
    cout << "list_4 reversed is: ";
    while(current2 != NULL)
    {
        cout << current2 -> value << " ";
        current2 = current2 -> next;
    }
    cout << endl << endl;
    temp1 = NULL;
    current = list_4;
    while(current != NULL)
    {
        temp2 = current->next;
        current ->next = temp1;
        temp1 = current;
        current = temp2;

    }
    list_4 = temp1;
    current2 = list_4;
    while(current2 != NULL)
    {
        current2 = current2 -> next;
    }

}

void LinkedList::moveEle()
{
    ListNode* current; // temp node
    ListNode* lastEle; // temp node for last element
    ListNode* thrdEle; // temp node for third element
    ListNode* newNode = new ListNode; // new node to be put between the 3rd and 4th elements
    current = list_4;
    int counter2 = 0; // counter for getting to third element
    while(current != NULL)
    {

        if(current->next == NULL)
        {
            lastEle = current;
            newNode -> value = lastEle -> value; // gets value of last element
        }
        current = current ->next;
        counter2++; // increment for 3rd element
        if(counter2 == 3)
        {
            thrdEle = current; // gets third element
        }
    }
    newNode ->next = thrdEle -> next; // moves new node between the elements
    thrdEle ->next = newNode; // fixes the list
    current = list_4;
    while(current->next->next != NULL)
    {
        current = current -> next;
    }
    current ->next = NULL; //gets rid of last element
    current = list_4;
    cout  << "The program will now move the last element of list_4";
    cout << " the list to between the 3rd and 4th elements of the list";
    cout << endl << endl << "list_4 now consists of: ";
     while(current != NULL) // display list_4
    {
        cout << current -> value << " ";
        current = current -> next;
    }
    cout << endl;
}

void LinkedList::sortList()
{
    ListNode* current; // temp node
    int valueTBS; // value to be sorted
    int sizeOfList = 0; // counter for size of list
    current = list_4;
    while(current != NULL) // get size of list
    {
        current = current->next;
        sizeOfList++;
    }
    current = list_4;
    for(int i = 0; i < sizeOfList; i++)
    {
        while(current ->next)
        {
            if(current->value > current->next->value)
            {
                valueTBS = current->value; // gets value of current node
                current->value = current->next->value; // swaps the values
                current->next->value = valueTBS; // swaps the values
            }
            current = current->next;// increments the list
        }
        current = list_4; // reset for next search
    }
    current = list_4;
    cout << endl;
    cout << "list_4 will now be sorted." << endl << endl;
    cout << "list_4 consists of: ";
    while(current != NULL) // displays list_4
    {
       cout << current -> value << " ";
        current = current -> next;
    }
    cout << endl<< endl;;

}

int main()
{
    LinkedList A = LinkedList();
    char input;
    cout << "This is my linked lists program.";
    cout << endl << "It will randomly generate list_1 and list_2, combine";
    cout << " them into list_3," << endl << "remove all the duplicates and become list_4,";
    cout << " count the elements of list_4, display list_4 in reverse,";
    cout << " move the last " << endl << "element in between the third and fourth element of list_4 ";
    cout << " then sort list_4 in ascending order." << endl << endl;
    do{
    A.buildLists();
    A.List3();
    A.displayFOccur();
    A.removeDups();
    A.countEle();
    A.disListBack();
    A.moveEle();
    A.sortList();
    cout << "If you want to run the program again enter 'y' or 'Y'";
    cout << endl << "else the program will terminate: ";
    cin >> input;
    cout << endl << endl << endl << endl;
    }while(input == 'Y'|| input == 'y');
    cout << endl;
    cout << "This LL program is implemented by :" << endl;
    cout << "Jacob Pangonas - March 5 th, 2018" << endl;
    return 0;
}
