//  Roster Number/s : 29
//
//  Author: Jacob Pangonas
//  Due Date: 4/9/2018
//  Programing Assignment Number 5
//
// Spring 2018 - CS 3358 - 01
//
// Instructor: Husain Gholooom
//
// This program uses recursive functions to display squares of integers in
// ascending order, raise a number to a power of 2, return the maximum element
// quick sort a function in descending order
// sums all the digits of a number and determine if the numbers in the array
// are prime

#include<iostream>
#include <cstdlib>
#include <ctime>
#include<limits>
using namespace std;

void displayFTenEle(int[], int); // displays first 10 elements
void displaySquares(int); // displays the squares of the array
int raisePower(int[], int); // raises the first number in the array by 2
void returnMax(int[], int, int); // returns maximum element
void quickSort(int [], int, int); // quick sorts the array in descending order
void sumofDig(int, int, int&); // adds the digits of the first
//number of the array
void isPrime(int[], int, int);// checks if numbers in the array are prime

void displayFTenEle(int a[], int i)
{

    cout << a[i] << " ";
    i++;
    if(i<10)
    {
        displayFTenEle(a, i);
    }
}

void displaySquares(int i)
{
    if(i > 1)
    {
     displaySquares(i-1);
    }
    cout << i << " " << i*i << endl;
}

int raisePower(int t, int i)
{
    if(i==0)
    {
        i++;
        t = t*raisePower(t,i);
    }
    return t;
}

void returnMax(int a[], int i, int m, int s)
{
    if(i == -1)
    {
        cout << "Max number of ( ";
        for(int j = 0; j<s; j++)
        {
            if(j+1 == s)
            {
                cout << a[j]<< " ";
            }
            else
            cout << a[j] << " , ";
        }
        cout << ") is: " << m << endl;
    }
    else
    {
        if(m < a[i])
        {
            m = a[i];
        }
        i--;
        returnMax( a, i, m , s);
    }
}

void quickSort(int a[], int l, int r)
{
    int i = l;// l = first element
    int j = r;// r = last element
    int temp = 0; // temp variable for swapping
    int s = a[(l+r)/2]; // s = pivot value
    while(i<=j)
    {
        while(a[i]>s)
        {
            i++;
        }
        while(a[j]<s)
        {
            j--;
        }
        if(i<=j)
        {
            temp = a[i];
            a[i] = a[j];
            a[j] = temp;
            i++;
            j--;
        }
    }

    if(l<j)
    {
        quickSort(a,l,j);
    }
    if(i<r)
    {
        quickSort(a,i,r);
    }
}

void sumofDig(int i, int j, int &sum)
{
    if(i>0)
    {
    sum = sum+(i%10);
    i = i/10;
    sumofDig(i, j, sum);
    }
}

void isPrime(int a[], int s, int i)
{
    if(i<s)
    {
        if(a[i]%2 == 0 || a[i]%3 == 0 || a[i]%5 == 0 || a[i]%7 == 0)
        {
            cout << a[i] << " is Not Prime" << endl;
        }
        else
        {
            cout << a[i] << " is Prime" << endl;
        }
        i++;
        isPrime(a,s,i);
    }
}
int main()
{
    int SIZE; // size of array
    int checker = 0; // checker for do while
    int checker2 = 1;// checker for do while
    char userIn;// user input for menu
    int temp = 0;// temp variable for setups
    int temp2 = 0;// temp variable for setups
    int temp3 = 0;// temp variable for setups
    cout << "Think Recursively" << endl << endl;
    cout << "The function of this program of this program is to" << endl;
    cout << "use recursion in order to perform the following operations :-";
    cout << endl << endl;
    cout << "   1. Display squares of integers in ascending order from 1 to ";
    cout << "the" << endl << "  last element in the array"<< endl;
    cout << "   2. Raise the first number to a power 2"<< endl;
    cout << "   3. Find the array's max value." << endl;
    cout << "   4. Sort the array in descending order" << endl;
    cout << "   5. Calculating sum of digits" << endl;
    cout << "   6. Determine if a number is prime(processes all array values)";
    cout << endl << endl;
    do
    {
        cout <<"Select from the following menu" << endl;
        cout <<"A.  Enter Array Size that is >=10 and <=1000 >." << endl;
        cout <<"X.  Terminate The Program       ";
        cin >> userIn;
        if(userIn == 'a'||userIn == 'A')
        {
            cout << endl << endl;
            cout << "Enter Array Size: ";
            do
            {
                cin >> SIZE;
                if(SIZE>=10 && SIZE <=1000)
                {
                    checker = 1;
                    int genArray[SIZE];
                    srand(time(NULL));
                    int ranNumber = std::rand() % 990;
                    ranNumber = ranNumber+10;
                    for(int i = 0; i<SIZE; i++)
                    {
                        genArray[i] = ranNumber;
                        ranNumber = std::rand() % 990;
                        ranNumber = ranNumber+10;
                    }
                    cout << endl;
                    cout << "The generated array is: " << endl << endl;
                    displayFTenEle(genArray, temp);
                    // squareing table begins
                    temp = genArray[SIZE-1];
                    cout << endl << endl;
                    cout << "Table of square values 1 - " << temp;
                    cout << endl << endl;
                    cout << "N N Squared" << endl;
                    displaySquares(temp);
                    // squareing table ends
                    cout << endl;
                    // raising to power of 2 begins
                    temp = 0;
                    temp2 = genArray[0];
                    temp3 = raisePower(temp2, temp);
                    cout << "Power Function:" << endl << endl;
                    cout << temp2 << " raised to the 2nd power is: " << temp3;
                    // raising to power of 2 ends
                    cout << endl << endl;
                    //return max begins
                    temp = SIZE -1;
                    temp2 = genArray[0];
                    temp3 = SIZE;
                    returnMax(genArray, temp, temp2, temp3);
                    // return max ends
                    // quick sort begins
                    clock_t c_start;
                    temp = sizeof(genArray)/sizeof(int);
                    temp2 = SIZE -1;
                    c_start = clock();
                    quickSort(genArray,0,temp-1);
                    clock_t c_end;
                    temp = 0;
                    cout << endl << endl;
                    cout << "Sorted Array" << endl << endl;
                    for(int i = 0; i<SIZE; i++)
                    {
                        cout << genArray[i] << " ";
                    }
                    c_end = clock();
                    long double time_elapsed_ms;
                    time_elapsed_ms = 1000.0 * (c_end-c_start)/CLOCKS_PER_SEC;
                    cout << endl << endl;
                    cout << "Start Time :   " << c_start<< endl;
                    cout << "End Time   :   " << c_end<< endl;
                    cout << "Actual CPU Clock Time: ";
                    cout << time_elapsed_ms << endl;
                    // quick sort ends
                    cout << endl << endl;
                    //sum of digits begins
                    temp = genArray[0];
                    temp2 = genArray[0];
                    temp3 = 0;
                    sumofDig(temp,temp2, temp3);
                    cout << "Sum of the digits for the number " << temp2;
                    cout << " is " << temp3;
                    cout << endl << endl;
                    // sum of digits ends
                    // is prime begins
                    temp = SIZE;
                    temp2 = 0;
                    cout << "Is it prime:" << endl << endl;
                    isPrime(genArray, temp, temp2);
                    // is prime ends
                    cout << endl << endl;
                }
                else if(SIZE<10 || SIZE >1000)
                {
                    cout << "*** Invalid Array Size Value ***" << endl;
                    cout << "*** Enter Array Size That is >= 10 and <= 1000: ";
                }
                else
                {
                    if(cin.fail()) // check for valid input
                    {
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(),'\n');
                        cout << "*** Invalid Array Size Value ***" << endl;
                        cout << "Enter an integer not a char: ";

    }
                }
            }while(checker!= 1);
                checker = 0;
        }
        else if(userIn == 'x' || userIn == 'X')
        {
            checker2 = 0;
        }
        else
        {
            cout << "*** Invalid Option ***" << endl << endl;
        }

    }while(checker2 ==1);
    cout << endl;
    cout << "Jacob Pangonas - Tweak Programing Developer" << endl;
    cout << "April 2018" << endl;

    return 0;
}
